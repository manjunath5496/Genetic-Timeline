#!/usr/bin/python

import re
import math

def loadTree(filename):
#This function reads a file in Newick format and returns our simple
#dictionary-based data structure for trees.
#Uses parseTree() to interpret input string.
	f = open(filename,'r')
	exp = f.read()
	f.close

	exp = exp.replace(';','') #ignore trailing (or other) semi-colons
	exp = re.sub(r'\s+','',exp) #ignore whitespace
	exp = re.sub(r'\n','',exp)
	exp = re.sub(r'\[.*\]','',exp) #ignore bracketed clauses

	return parseTree(exp)


def makeLeaf(name,length):
#This function returns a tree structure corresponding to a single leaf
	return { 'left':None, 'right':None, 'name':name, 'length':length }


def parseTree(exp):
#This function takes a string in Newick format and parses it recursively.
#Each clause is expected to be of the general form (a:x,b:y):z
#where a and b may be subtrees in the same format.

	if ',' not in exp: #if this is a leaf
		name, length = exp.split(':')
		length = float(length)
		return makeLeaf(name,length)

	#uses the regular expression features of Python
	distPattern = re.compile(r'(?P<tree>\(.+\))\:(?P<length>[e\-\d\.]+)$')
	m = distPattern.search(exp)
	length = 0
	if m:			
		if m.group('length'): length = float( m.group('length') )
		exp = m.group('tree')
	if length == '': length = 0

	#Use the parseExp function to return the left and right hand sides
	#of the expression (e.g., a & b from (a,b))
	lhs, rhs = parseExp(exp)

	#Now package into a tree data structure
	return { "name":"internal",
			 "left":parseTree(lhs), #recursively set up subtrees
			 "right":parseTree(rhs),
			 "length":length }


def parseExp(exp):
	#Parse expression of type "a,b" into a & b where a and b can be
	#Newick formatted strings.
	chars = list(exp[1:-1]) #get rid of surrounding parens, and split to list
	count = 0
	lhs = True #boolean to distinguish left and right side of the comma
	left = '' #store the left substring
	right = '' #store the right substring

	#a little tricky to deal with nested parens correctly
	for c in chars:
		if c == '(':
			count += 1
		if c == ')':
			count -= 1
		if (c == ',') and (count == 0) and (lhs) :
			lhs = False
			continue

		if lhs: left += c
		else: right += c

	#Now return the left and right substrings
	return [ left, right ]

#This function returns the average root to leaf distance in a
#phylogenetic tree.  This solution weights subtrees by the number of
#leaves in each subtree

def avgDistanceWeighted(tree):

	averageDistance = tree['length']

	# handle the leaves
	if tree['name'] is not 'internal':
		numLeaves = 1
	else:
		[dL,nL] = avgDistanceWeighted(tree['left'])
		[dR,nR] = avgDistanceWeighted(tree['right'])
		averageDistance += (dL*nL + dR*nR)/(nL+nR)
		numLeaves = nL + nR
	return [averageDistance,numLeaves]

#This function returns the average root to leaf distance
#in a phylogenetic tree.  it doesn't weight subtrees.

def avgDistanceUnWeighted(tree):

	averageDistance = tree['length']

	# handle the leaves
	if tree['name'] is not 'internal':
		numLeaves = 1
	else:
		[dL,nL] = avgDistanceUnWeighted(tree['left'])
		[dR,nR] = avgDistanceUnWeighted(tree['right'])
		averageDistance += (dL*1 + dR*1)/(2)
		numLeaves = nL + nR
	return [averageDistance,numLeaves]

#This function returns the minimum root to leaf distance
#in a phylogenetic tree, and the name of the node with the
#minimum.

def minDistance(tree):

    my_dist = tree['length']

    # stop at leaves
    if tree['name'] is not "internal":
	    return [my_dist,tree['name']]

    # if not a leaf:
    l_dist = minDistance(tree['left'])
    r_dist = minDistance(tree['right'])

    # append current node's length:
    l_dist[0] += my_dist
    r_dist[0] += my_dist

    # perform comparison (note that if equidistant, this returns left
    # tree
    if l_dist[0] <= r_dist[0]:
	    return l_dist
    else:
	    return r_dist

#This function returns the maximum root to leaf distance
#in a phylogenetic tree, and the name of the node with the
#maximum.
#If two or more leafs are equidistant, pick the one on the left.
def maxDistance(tree):

    my_dist = tree['length']

    # stop at leaves
    if tree['name'] is not "internal":
	    return [my_dist,tree['name']]

    # if not a leaf:
    l_dist = maxDistance(tree['left'])
    r_dist = maxDistance(tree['right'])

    # append current node's length:
    l_dist[0] += my_dist
    r_dist[0] += my_dist

    # perform comparison (note that if equidistant, this returns left
    # tree
    if l_dist[0] >= r_dist[0]:
	    return l_dist
    else:
	    return r_dist

tree = loadTree('tree3.txt')

print "Average distance (weighted):", avgDistanceWeighted(tree)[0]
print "Average distance (unweighted):", avgDistanceUnWeighted(tree)[0]
print "Min distance/node", minDistance(tree)
print "Max distance/node", maxDistance(tree)

