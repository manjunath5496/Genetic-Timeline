from Protein import Protein;
from Topology import Topology;
from Residue import Residue;
from RotamerLib import RotamerLib;

top = Topology('top_all27_prot_na.inp');
rotolib = RotamerLib('bbind02.May.lib');
lj = Energy.loadLJParameters('lj_params.inp');

# Assign a protein object with sequence "ACDEFGHIKLMNPQRSTVWY"
p = #insert code here

#now select the active rotamer
for res in p.getResidues():
    res.selectRotamer(0);

#write this structure to the file "allRes.pdb"
p.#insert code

#load a protein from a pdb file
q = Protein( top, rotolib );
q.loadFromPDB( top, '1shfA_h.pdb' );

#loop over residues in q
#  print out amino acid:list of dihedral angles in rotamer 0
for res in q.getResidues():
#insert your code here
